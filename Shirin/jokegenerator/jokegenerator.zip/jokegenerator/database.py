list = [
"Q: Why was six scared of seven? A: Because seven - ate - nine.",
"Q: What is the difference between snowmen and snowwomen? A: Snowballs.",
"A computer once beat me at chess, but it was no match for me at kick boxing.",
"What did one ocean say to the other ocean? Nothing, they just waved.",
"A day without sunshine is like, .... night.",
"What is faster Hot or cold? Hot, because you can catch a cold.",
"Do not argue with an idiot. He will drag you down to his level and beat you with experience."
]
